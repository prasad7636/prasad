// Mobile Menu Toggle
const menuToggle = document.getElementById('menu-toggle');
const mobileMenu = document.getElementById('mobile-menu');
const menuIcon = document.getElementById('menu-icon');

menuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
    menuIcon.textContent = mobileMenu.classList.contains('hidden') ? '☰' : '✕';
});

// Authentication and Profile Management
let currentUser = null;

function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function switchForm(modalId) {
    closeModal('login-modal');
    closeModal('signup-modal');
    openModal(modalId);
}

function handleSignup() {
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value.trim();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showToast('Please enter a valid email', 'error');
        return;
    }
    if (password.length < 6) {
        showToast('Password must be at least 6 characters', 'error');
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.some(user => user.email === email)) {
        showToast('Email already exists', 'error');
        return;
    }

    users.push({ email, password, reports: [] });
    localStorage.setItem('users', JSON.stringify(users));
    showToast('Sign up successful! Please login.', 'success');
    closeModal('signup-modal');
    openModal('login-modal');
}

function handleLogin() {
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value.trim();

    if (!email || !password) {
        showToast('Please enter email and password', 'error');
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.email === email && u.password === password);

    if (!user) {
        showToast('Invalid email or password', 'error');
        return;
    }

    currentUser = user;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    showToast('Login successful!', 'success');
    closeModal('login-modal');
    updatePageVisibility('dashboard');
    initializeForm();
    setupEventListeners();
}

function handleLogout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    showToast('Logged out successfully', 'info');
    updatePageVisibility('home');
}

function toggleEditForm() {
    const form = document.getElementById('edit-details-form');
    const button = document.querySelector('.edit-btn');
    form.classList.toggle('hidden');
    button.textContent = form.classList.contains('hidden') ? 'Edit Details' : 'Cancel Edit';
    // Clear the form fields when hiding the form
    if (form.classList.contains('hidden')) {
        document.getElementById('edit-email').value = '';
        document.getElementById('edit-password').value = '';
    }
}

function updateUserDetails() {
    const newEmail = document.getElementById('edit-email').value.trim();
    const newPassword = document.getElementById('edit-password').value.trim();

    if (!newEmail && !newPassword) {
        showToast('Please enter at least one field to update', 'error');
        return;
    }

    if (newEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
        showToast('Please enter a valid email', 'error');
        return;
    }

    if (newPassword && newPassword.length < 6) {
        showToast('Password must be at least 6 characters', 'error');
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.email === currentUser.email);

    if (newEmail) {
        const emailExists = users.some((user, index) => user.email === newEmail && index !== userIndex);
        if (emailExists) {
            showToast('Email already exists', 'error');
            return;
        }
        users[userIndex].email = newEmail;
        currentUser.email = newEmail;
        document.getElementById('profile-email').textContent = newEmail;
    }

    if (newPassword) {
        users[userIndex].password = newPassword;
        currentUser.password = newPassword;
    }

    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    document.getElementById('edit-email').value = '';
    document.getElementById('edit-password').value = '';
    showToast('Details updated successfully!', 'success');
    toggleEditForm(); // Hide the form after saving
}

function updatePageVisibility(page) {
    const sections = ['home', 'prediction-info', 'report-info', 'dashboard', 'profile', 'about', 'how-it-works', 'health-journey', 'contact'];
    const authLinks = document.getElementById('auth-links');
    const profileLink = document.getElementById('profile-link');
    const mobileAuthLinks = document.getElementById('mobile-auth-links');
    const mobileProfileLink = document.getElementById('mobile-profile-link');

    sections.forEach(section => {
        const element = document.getElementById(section);
        if (element) element.classList.add('hidden');
    });

    if (page === 'home') {
        document.getElementById('home').classList.remove('hidden');
        document.getElementById('prediction-info').classList.remove('hidden');
        document.getElementById('report-info').classList.remove('hidden');
        document.getElementById('about').classList.remove('hidden');
        document.getElementById('how-it-works').classList.remove('hidden');
        document.getElementById('health-journey').classList.remove('hidden');
        document.getElementById('contact').classList.remove('hidden');
        authLinks.classList.remove('hidden');
        profileLink.classList.add('hidden');
        mobileAuthLinks.classList.remove('hidden');
        mobileProfileLink.classList.add('hidden');
    } else if (page === 'dashboard') {
        document.getElementById('dashboard').classList.remove('hidden');
        authLinks.classList.add('hidden');
        profileLink.classList.remove('hidden');
        mobileAuthLinks.classList.add('hidden');
        mobileProfileLink.classList.remove('hidden');
        document.getElementById('profile-email').textContent = currentUser.email;
        renderSavedReports();
    } else if (page === 'profile') {
        document.getElementById('profile').classList.remove('hidden');
        authLinks.classList.add('hidden');
        profileLink.classList.remove('hidden');
        mobileAuthLinks.classList.add('hidden');
        mobileProfileLink.classList.remove('hidden');
        document.getElementById('profile-email').textContent = currentUser.email;
        renderSavedReports();
    }
}

function saveHealthReport() {
    if (!currentUser) {
        showToast('Please login to save reports', 'error');
        return;
    }

    const reportSection = document.getElementById('report');
    const reportCardsContainer = reportSection.querySelector('.space-y-8');
    const reportCards = reportCardsContainer.querySelectorAll('.report-card');
    let reportContent = '';
    reportCards.forEach(card => {
        reportContent += card.outerHTML;
    });

    const report = {
        date: new Date().toISOString(),
        content: reportContent
    };

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.email === currentUser.email);
    users[userIndex].reports.push(report);
    localStorage.setItem('users', JSON.stringify(users));
    currentUser.reports = users[userIndex].reports;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    showToast('Report saved successfully!', 'success');
    renderSavedReports();
}

function unsaveReport(index) {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.email === currentUser.email);
    users[userIndex].reports.splice(index, 1);
    currentUser.reports = users[userIndex].reports;
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    showToast('Report removed successfully!', 'info');
    renderSavedReports();
}

function renderSavedReports() {
    const reportsList = document.getElementById('saved-reports-list');
    reportsList.innerHTML = '';
    if (currentUser && currentUser.reports && currentUser.reports.length > 0) {
        currentUser.reports.forEach((report, index) => {
            // Create a temporary container to parse the report content
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = report.content;

            // Select all report-card elements and exclude text-center
            const reportCards = tempDiv.querySelectorAll('.report-card');
            let filteredContent = '';
            reportCards.forEach(card => {
                filteredContent += card.outerHTML;
            });

            // Render the filtered content
            const reportDiv = document.createElement('div');
            reportDiv.className = 'saved-report';
            reportDiv.innerHTML = `
                <button class="unsave-btn" onclick="unsaveReport(${index})">Unsave</button>
                <p><strong>Report ${index + 1} - ${new Date(report.date).toLocaleDateString()}</strong></p>
                <div class="space-y-8">
                    ${filteredContent}
                </div>
            `;
            reportsList.appendChild(reportDiv);
        });
    } else {
        reportsList.innerHTML = '<p>No saved reports yet.</p>';
    }
}

// Event Listeners for Navigation Links
document.getElementById('login-link').addEventListener('click', (e) => {
    e.preventDefault();
    openModal('login-modal');
});
document.getElementById('signup-link').addEventListener('click', (e) => {
    e.preventDefault();
    openModal('signup-modal');
});
document.getElementById('mobile-login-link').addEventListener('click', (e) => {
    e.preventDefault();
    openModal('login-modal');
});
document.getElementById('mobile-signup-link').addEventListener('click', (e) => {
    e.preventDefault();
    openModal('signup-modal');
});

document.querySelectorAll('a[href="#home"]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        updatePageVisibility('home');
    });
});
document.querySelectorAll('a[href="#dashboard"]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        if (currentUser) updatePageVisibility('dashboard');
        else openModal('login-modal');
    });
});
document.querySelectorAll('a[href="#profile"]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        if (currentUser) updatePageVisibility('profile');
        else openModal('login-modal');
    });
});

// Symptom Checker Functionality
let symptoms = [];
let currentSymptom = '';

const commonSymptoms = [
    'Headache', 'Fever', 'Cough', 'Fatigue', 'Nausea', 'Dizziness',
    'Chest Pain', 'Shortness of Breath', 'Abdominal Pain', 'Joint Pain'
];

function initializeForm() {
    renderCommonSymptoms();
    updateUI();
}

function setupEventListeners() {
    const input = document.getElementById('symptom-input');
    
    input.addEventListener('input', function(e) {
        currentSymptom = e.target.value;
        updateAddButton();
        updateActionButtons();
    });
    
    input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addSymptom();
        }
    });
}

function renderCommonSymptoms() {
    const container = document.getElementById('common-symptoms');
    container.innerHTML = '';
    
    commonSymptoms.forEach(symptom => {
        const badge = document.createElement('span');
        badge.className = 'symptom-badge common';
        badge.textContent = symptom;
        badge.onclick = () => addSymptomFromList(symptom);
        container.appendChild(badge);
    });
}

function addSymptom() {
    const input = document.getElementById('symptom-input');
    const symptom = input.value.trim();
    
    if (symptom && !symptoms.includes(symptom)) {
        symptoms.push(symptom);
        input.value = '';
        currentSymptom = '';
        updateUI();
        showToast(`Added "${symptom}" to your symptoms`, 'success');
    }
}

function addSymptomFromList(symptom) {
    if (!symptoms.includes(symptom)) {
        symptoms.push(symptom);
        updateUI();
        showToast(`Added "${symptom}" to your symptoms`, 'success');
    }
}

function removeSymptom(symptom) {
    symptoms = symptoms.filter(s => s !== symptom);
    updateUI();
    showToast(`Removed "${symptom}" from your symptoms`, 'info');
}

function updateUI() {
    updateAddedSymptoms();
    updateAddButton();
    updateActionButtons();
}

function updateAddedSymptoms() {
    const container = document.getElementById('added-symptoms-container');
    const symptomsGrid = document.getElementById('added-symptoms');
    const countSpan = document.getElementById('symptom-count');
    
    if (symptoms.length > 0) {
        container.style.display = 'block';
        countSpan.textContent = symptoms.length;
        
        symptomsGrid.innerHTML = '';
        symptoms.forEach(symptom => {
            const badge = document.createElement('span');
            badge.className = 'symptom-badge added';
            badge.innerHTML = `
                ${symptom}
                <button class="remove-btn" onclick="removeSymptom('${symptom}')">
                    ✕
                </button>
            `;
            symptomsGrid.appendChild(badge);
        });
    } else {
        container.style.display = 'none';
    }
}

function updateAddButton() {
    const addBtn = document.getElementById('add-btn');
    const input = document.getElementById('symptom-input');
    const isEnabled = !!input.value.trim();
    addBtn.disabled = !isEnabled;
    console.log('Add button state:', isEnabled ? 'enabled' : 'disabled');
}

function updateActionButtons() {
    const analyzeBtn = document.getElementById('analyze-btn');
    const resetBtn = document.getElementById('reset-btn');
    const input = document.getElementById('symptom-input');
    
    const hasSymptoms = symptoms.length > 0;
    analyzeBtn.disabled = !hasSymptoms;
    resetBtn.disabled = !hasSymptoms && !input.value.trim();
}

async function analyzeSymptoms() {
    if (symptoms.length === 0) {
        showToast('Please add at least one symptom', 'error');
        return;
    }

    try {
        console.log("Sending symptoms:", symptoms); // Debug line
        const res = await fetch('http://localhost:5000/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ symptoms: symptoms })
        });

        const result = await res.json();

        if (result.error) {
            showToast(result.error, 'error');
            return;
        }

        const { disease, description, precautions, medications, diets, workouts } = result;
        const reportTexts = document.querySelectorAll('.report-text');
        reportTexts[0].textContent = disease;
        reportTexts[1].textContent = description;
        reportTexts[2].textContent = medications.join(', ');
        reportTexts[3].textContent = diets.join(', ');
        reportTexts[4].textContent = precautions.flat().join(', ');
        reportTexts[5].textContent = workouts.join(', ');

        showToast('Analysis complete! Check your health report below.', 'success');
        document.getElementById('report').scrollIntoView({ behavior: 'smooth' });

    } catch (err) {
        console.error("Error fetching prediction:", err);
        showToast('Server error. Try again later.', 'error');
    }
}


function resetForm() {
    symptoms = [];
    document.getElementById('symptom-input').value = '';
    currentSymptom = '';
    updateUI();
    showToast('Symptoms cleared', 'info');
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 24px;
        background-color: ${type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#3b82f6'};
        color: white;
        border-radius: 6px;
        z-index: 1000;
        font-weight: 500;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    `;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Initialize on Page Load
document.addEventListener('DOMContentLoaded', () => {
    currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        updatePageVisibility('dashboard');
        initializeForm();
        setupEventListeners();
    } else {
        updatePageVisibility('home');
    }
});