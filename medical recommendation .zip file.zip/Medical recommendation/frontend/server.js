// filepath: d:\Mini project(Medical recommendation)\Mini project(Medical recommendation)\frontend\server.js
const express = require('express');
const path = require('path');

const app = express();
const PORT = 4000;

// Serve static files from the frontend directory
app.use(express.static(path.join(__dirname, '')));

// Default route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html')); // Ensure you have an index.html file
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});